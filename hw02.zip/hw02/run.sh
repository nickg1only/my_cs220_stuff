scala -cp bin cs220.Main cereal.csv
