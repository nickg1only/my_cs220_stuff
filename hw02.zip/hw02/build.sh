mkdir -p bin
rm -rf bin/*
fsc -d bin $(find src -name '*.scala')
