package cs220.ds

trait CerealCsvTrait extends CsvData {
 // Returns the rows containing the minimum calorie cereals. We
 // return multiple rows because we may have multiple cereals with
 // the same minimum calories.
 def minCalories(): List[List[String]]

 // Returns the rows containing the maximum calorie cereals. We
 // return multiple rows because we may have multiple cereals with
 // the same maximum calories.
 def maxCalories(): List[List[String]]

 // Returns the rows containing high fiber cereals. High fiber
 // is in this case considered at least 5g of fiber. We return multiple
 // rows because we may have multiple high fiber cereals
 def highFiber(): List[List[String]]

 // Returns the rows containing high protein cereals. High protein
 // is in this case considered at least 4g of protein. We return multiple
 // rows because we may have multiple high protein cereals
 def highProtein(): List[List[String]]

 // Returns the rows containing cereals with the maximum sugar-to-carbohydrate
 // ratio. We return multiple rows because we may have multiple cereals
 // with the same maximum sugar-to-carbohydrate ratio.
 def maxSugarToCarbRatio(): List[List[String]]
}
