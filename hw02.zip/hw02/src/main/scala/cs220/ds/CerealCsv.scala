package cs220.ds

import scala.io.Source

class CerealCsv(val hs: List[String], val ds: List[List[String]]) extends CerealCsvTrait {
 def nrows(): Int = ds.length //returns the number of rows in the data (excluding the header).
 def ncols(): Int = hs.length //returns the number of columns in the data.
 def rows(): List[List[String]] = ds //returns the rows in the file.
 def headers(): List[String] = hs //returns a list of the header names in the file.
 def row(idx: Int): List[String] = ds(idx) //returns a specific row
 def column(hname: String): (String, List[String]) = {
	val colIdx = hs indexOf hname //assigns the index of the column in the data containing the header name 
	if(colIdx == -1){
	 hname -> List() //returns pairing of header name and empty list
	}
	else{
	 val colData = //assigns a list of the data at that column
	  for {
	    line <- ds //assigns the list of strings at each row in the data
	    value = line(colIdx) //assigns the value in the list of strings at the column index
	  } yield value //adds that value to the list
	 hname -> colData //returns pairing of header name and the list of data from the column
	}
 }
 def rowMatch(hname: String, value: String): List[List[String]] = {
	val colIdx = hs indexOf hname //assigns the index of the column in the data containing the header name
	if(colIdx == -1){
	 List() //returns empty list
 	}
 	else{
	 val lines = //assigns a list of rows from the data containing the value
	  for {
	    line <- ds //assigns the list of strings at each row in the data
	    if(line(colIdx) == value) //compares value to the value at the column index in the row (list of strings)
	  } yield line //adds the row (list of strings) to the list
	 lines //return statement
	}
 }
 def toCSV(xss: List[List[String]]): String = {
	val lines = //assigns a list of comma-seperated strings which represent each line in the xss data file
	 for {
	   line <- xss //extracts a list of strings from the parameter list of list of strings
	   row = line.mkString(",") //converts that list of strings into one long comma-seperated string
	 } yield row //adds that long comma-seperated string to the 'lines' list
	lines.mkString("\n") //return statement
 }
 def minCalories(): List[List[String]] = {
	val cal_col = column("calories")._2 //assigns the list of values from the "calories" column
	val cal_int_list = //the list of values converted from string into integer format
	 for {
	   cal_str <- cal_col //extracts a single string from the list of values from the "calories" column
	   cal_int = cal_str.toInt //converts the string to an integer
	 } yield cal_int //adds that integer to the list
	val min_cal = cal_int_list.sorted.head.toString //extracts the minimum integer on the list and assigns it
	rowMatch("calories", min_cal) //return statement
 }
 def maxCalories(): List[List[String]] = {
	val cal_col = column("calories")._2 //assigns the list of values from the "calories" column
	val cal_int_list = //the list of values converted from string into integer format
	 for {
	   cal_str <- cal_col //extracts a single string from the list of values from the "calories" column
	   cal_int = cal_str.toInt //converts the string to an integer
	 } yield cal_int //adds that integer to the list
	val max_cal = cal_int_list.reverse.head.toString //extracts the maximum integer on the list and assigns it
	rowMatch("calories", max_cal) //return statement
 }
 def highFiber(): List[List[String]] = {
	val fib_col = column("fiber")._2 //assigns the list of values from the "fiber" column
	val high_fib_list = //assigns the list of values which are considered "high fiber", namely at least 5g of fiber
	 for {
	  fib_val <- fib_col //extracts a single value from the list of values
	  if(fib_val.toInt >= 5) //filters for fiber values that are at least 5
	 } yield fib_val //adds the filtered fiber values to list
	val high_fib_rows = //assigns the rows that contain high fiber values
	 for {
	   high_fib_val <- high_fib_list //iterates through each value in the 'high fiber' list
	   row <- rowMatch("fiber", high_fib_val.toString) //extracts a row from the list of rows containing the high fiber value
	 } yield row //adds the row of the data to list
	high_fib_rows //return statement
 }
 def highProtein(): List[List[String]] = {
	val prot_col = column("protein")._2 //assigns the list of values from the "protein" column
	val high_prot_list = //assigns the list of values which are considered "high protein", namely at least 4g of protein
	 for {
	  prot_val <- prot_col //extracts a single value from the list of values
	  if(prot_val.toInt >= 4) //filters for protein values that are at least 4
	 } yield prot_val //adds the filtered protein values to list
	val high_prot_rows = //assigns the rows that contain high protein values
	 for {
	   high_prot_val <- high_prot_list //iterates through each value in the 'high protein' list
	   row <- rowMatch("protein", high_prot_val.toString) //extracts a row from the list of rows containing the high protein value
	 } yield row //adds the row of the data to list
	high_prot_rows //return statement
 }
 def maxSugarToCarbRatio(): List[List[String]] = {
	val sug_col = column("sugars")._2 //assigns the list of values from the "sugars" column
	val carb_col = column("carbo")._2 //assigns the list of values from the "carbo" column
	val sug_to_carb_ratios = //assigns a list of the ratios of sugar to carbohydrate amounts
	 for {
	  i <- (0 to ds.length-1).toList //assigns row index
	  sug_to_carb_ratio = sug_col(i).toFloat/(carb_col(i).toFloat) //assigns sugar-to-carb ratio value for given row index
	 } yield sug_to_carb_ratio //adds sugar-to-carb ratio to list
	val max_sug_to_carb_ratio = sug_to_carb_ratios.reverse.head //assigns the value of the max sugar-to-carb ratio
	val max_sug_to_carb_ratio_rows = //assigns the rows that contain the max sugar-to-carb ratio
	 for {
	   i <- (0 to ds.length-1).toList //assigns index for iteration
	   if(sug_to_carb_ratios(i) == max_sug_to_carb_ratio) //filters for the sugar-to-carb ratio being equal to the max ratio
	 } yield ds(i) //adds the row of the data with the max ratio to list
	max_sug_to_carb_ratio_rows //return statement
 }
}

object CerealCsv extends CsvReader[CerealCsvTrait] {
  //Returns a CerealCsvTrait object with data and headers from the file whose name is described in the String parameter
  def read(file: String): CerealCsvTrait = {
	val lines = Source.fromFile(file).getLines.toList //assigns a list of all the lines of the file
	val headers = lines.head.split(",").toList //assigns a list of the header names in the file
	val data = //assigns the data rows from the file excluding the header row
	 for {
	   line <- lines.tail;
	   row = line.split(",").toList
	 } yield row
	new CerealCsv(headers, data) //return statement
 }
}
