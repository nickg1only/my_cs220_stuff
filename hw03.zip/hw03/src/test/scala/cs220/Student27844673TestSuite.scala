package cs220

import cs220._
import org.scalatest.FunSuite

class Student27844673TestSuite extends FunSuite{

	test("An empty environment extended three times should have length 3"){
	   try{
		val eo = Environment
		val ee = eo.extend(Var("x"), Value(24))
		val eee = ee.extend(Var("y"), Value(36))
		val eeee = eee.extend(Var("z"), Value(48))
		assert(eeee.toList.length == 3)
	   }
	   catch{
		case _: NotImplementedError => fail("You have not implemented this method yet!")
	   }
	}
	
	test("Evaluation of a subtraction expression"){
    		val env = Environment.extend(Var("x"), Value(39))
    		val res = ExprParser.parse("x - 10") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 39 - 10 == 29
    		assert(v == Value(29))
    		assert(e == env)
  	}

	test("Evaluation of a multiplication expression"){
    		val env = Environment.extend(Var("x"), Value(39))
    		val res = ExprParser.parse("x * 10") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 39 * 10 == 390
    		assert(v == Value(390))
    		assert(e == env)
  	}

	test("Evaluation of a division expression"){
    		val env = Environment.extend(Var("x"), Value(40))
    		val res = ExprParser.parse("x / 10") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 40 / 10 == 4
    		assert(v == Value(4))
    		assert(e == env)
  	}

	test("Evaluation of a complicated expression"){
    		val env = Environment.extend(Var("x"), Value(39))
    		val res = ExprParser.parse("x * 2 - 8") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 39 * 2 - 8  == 70
    		assert(v == Value(70))
    		assert(e == env)
  	}

	test("Evaluation of a second complicated expression"){
    		val env = Environment.extend(Var("x"), Value(40))
    		val res = ExprParser.parse("x / 10 + 6") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 40 / 10 + 6 == 10
    		assert(v == Value(10))
    		assert(e == env)
  	}

	test("Evaluation of a subtraction expression"){
    		val env = Environment.extend(Var("x"), Value(39))
    		val res = ExprParser.parse("x - 10") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 39 - 10 == 29
    		assert(v == Value(29))
    		assert(e == env)
  	}

	test("Error thrown while dividing by zero"){
    		val env = Environment.extend(Var("x"), Value(39))
    		val res = ExprParser.parse("x - 10") match {
      		case ExprParseSuccess(program) =>
        		Evaluator.evalProgram(program, env)
      		case ExprParseFailure(message) => fail()
      		case _ => fail()
    		}
    		val EvaluationResult(v, e) = res
    		// 39 - 10 == 29
    		assert(v == Value(29))
    		assert(e == env)
  	}

}
