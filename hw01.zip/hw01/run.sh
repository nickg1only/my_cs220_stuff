java -cp bin cs220.Main
