rm -rf bin/*.java
javac -d bin src/main/java/cs220/util/*.java
javac -d bin -cp bin src/main/java/cs220/*.java
