package cs220.util;

public interface ScalaArray<T> {
  public void foreach(Function<T> fn);
}