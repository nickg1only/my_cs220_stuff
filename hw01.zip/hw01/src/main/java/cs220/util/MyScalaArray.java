package cs220.util;

public class MyScalaArray<T> implements ScalaArray<T> {
	private T[] array;
	
	public MyScalaArray(T[] arr){
		array = arr;
	}
	
	public void foreach(Function<T> fn){
		for(T obj : array){
			fn.apply(obj);
		}
	}
}