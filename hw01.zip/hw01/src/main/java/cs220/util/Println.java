package cs220.util;

public class Println<T> implements Function<T>{
	public void apply(T arg){
		System.out.println(arg);
	}
}