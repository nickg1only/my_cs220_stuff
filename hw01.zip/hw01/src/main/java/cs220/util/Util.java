package cs220.util;

public class Util{
	public static <T> ScalaArray<T> scalaArray(T[] jarray) {
		ScalaArray<T> sarray = new MyScalaArray<T>(jarray);
		return sarray;
	}

	public static <T> Function<T> println() {
		Function<T> myPrintln = new Println<T>();
		return myPrintln;
	}
}