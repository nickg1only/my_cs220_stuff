package cs220;

import cs220.util.*;

public class Main{
	public static void main(String[] args){
		String[] arr = { "Hello", "World" };
		Function<String> println = Util.println();
		ScalaArray<String> arrs  = Util.scalaArray(arr);
		arrs.foreach(println);
	}
}