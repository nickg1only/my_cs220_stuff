The base directory where all h2 databases will go.
